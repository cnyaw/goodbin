
function PtInRect(x, y, left, top, right, bottom)
  if (left <= x and right > x and top <= y and bottom > y) then
    return true
  else
    return false
  end
end

function GenStrObj(parent, x, y, str, texture, charw, charh)
  if (nil == str) then
    return -1
  end
  local _parent = parent
  if (nil == parent) then
    _parent = -1
  end
  local dummy = Good.GenDummy(_parent)
  if (-1 == dummy) then
    return -1
  end
  local _x, _y = x, y
  if (nil == x) then
    _x = 0
  end
  if (nil == y) then
    _y = 0
  end
  Good.SetPos(dummy, _x, _y)
  local _tex = texture
  if (nil == _tex) then
    _tex = Resource.GetTexId('font')
  end
  local _cw, _ch = charw, charh
  if (nil == _cw) then
    _cw = 16
  end
  if (nil == _ch) then
    _ch = 32
  end
  for i = 1, string.len(str) do
    local ch = string.byte(str, i) - 32
    local charx = _cw * math.floor(ch % 15)
    local chary = _ch * math.floor(ch / 15)
    local o = GenTexObj(dummy, _tex, _cw, _ch, charx, chary)
    Good.SetPos(o, (i - 1) * _cw, 0)
  end
  return dummy
end

function GenColorObj(parent, w, h, color, script)
  local _parent = parent
  if (nil == parent) then
    _parent = -1
  end
  local _script = script
  if (nil == script) then
    _script = ''
  end
  local o = Good.GenObj(_parent, -1, _script)
  if (-1 ~= o) then
    local _w, _h = w, h
    local _color = color
    if (nil == w) then
      _w = 16
    end
    if (nil == h) then
      _h = 16
    end
    if (nil == color) then
      _color = 0xffff0000
    end
    Good.SetDim(o, 0, 0, _w, _h)
    Good.SetBgColor(o, _color)
  end
  return o
end

function GenTexObj(parent, texture, w, h, srcx, srcy, script)
  local _parent = parent
  if (nil == parent) then
    _parent = -1
  end
  local _tex = texture
  if (nil == texture) then
    _tex = -1
  end
  local _script = script
  if (nil == script) then
    _script = ''
  end
  local o = Good.GenObj(_parent, _tex, _script)
  if (-1 ~= o) then
    local _w, _h = w, h
    if (nil == w) then
      _w = 16
    end
    if (nil == h) then
      _h = 16
    end
    local _srcx, _srcy = srcx, srcy
    if (nil == srcx) then
      _srcx = 0
    end
    if (nil == srcx) then
      _srcy = 0
    end
    Good.SetDim(o, _srcx, _srcy, _w, _h)
  end
  return o
end
