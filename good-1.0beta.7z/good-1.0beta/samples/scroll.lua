
Level = {}

scroll = function(id, offset)
  local x,y = Good.GetPos(id)
  x = x - offset
  Good.SetPos(id, x,y)
end

Level.OnStep = function(param)
  local id = param._id

  scroll(Good.FindChild(id, 'bg'), 0.5)
  scroll(Good.FindChild(id, 'bg2'), 0.25)
  scroll(Good.FindChild(id, 'sun'), 0.15)
end

