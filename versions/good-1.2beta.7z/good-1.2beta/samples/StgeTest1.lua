Level = {}

Level.OnCreate = function(param)
  Stge.RunScript('StgeTest1')
end

Level.OnNewParticle = function(param, particle)
  local u1 = Stge.GetUserData(particle, 0)
  local obj = Good.GenObj(-1, -1)
  Good.SetDim(obj, 0,0, 8, 8)
  if (1 == u1) then
    Good.SetBgColor(obj, 0xff00ff00)
  else
    Good.SetBgColor(obj, 0xffff0000)
  end
  Stge.BindParticle(particle, obj)
end

Level.OnKillParticle = function(param, particle)
  Good.KillObj(Stge.GetParticleBind(particle))
end