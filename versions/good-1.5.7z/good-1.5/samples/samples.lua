
local CurSel = 0

Level = {}

Level.OnCreate = function(param)
  for i = 1,8 do
    local btn = GenTexObj(-1, 1, 110, 110, 128 * ((i - 1) % 4), 128 * math.floor((i - 1) / 4))
    Good.SetPos(btn, (160 - 110)/2 + 160 * ((i - 1) % 2), 5 + 120 * math.floor(((i - 1) / 2)))
  end

  local o = GenColorObj(-1)
  Good.SetPos(o, 160 * (CurSel % 2), 5 + 120 * math.floor((CurSel / 2)))
  param.cur = o
end

Packages = {'mmc.txt', 'mario.txt', 'stge.txt', 'puzzle.txt', 'weeder.txt', 'breakout.txt', 'zelda.txt', 'life.txt'}

function PlayGame(sel)
  Good.CallPackage(Packages[1 + sel])
end

Level.OnStep = function(param)
  local x = CurSel % 2
  local y = math.floor(CurSel / 2)

  if (Input.IsKeyPushed(Input.LEFT)) then
    if (0 < x) then
      CurSel = CurSel - 1
      Good.SetPos(param.cur, 160 * (CurSel % 2), 5 + 120 * math.floor((CurSel / 2)))
    end
  elseif (Input.IsKeyPushed(Input.UP)) then
    if (0 < y) then
      CurSel = CurSel - 2
      Good.SetPos(param.cur, 160 * (CurSel % 2), 5 + 120 * math.floor((CurSel / 2)))
    end
  elseif (Input.IsKeyPushed(Input.DOWN)) then
    if (3 > y) then
      CurSel = CurSel + 2
      Good.SetPos(param.cur, 160 * (CurSel % 2), 5 + 120 * math.floor((CurSel / 2)))
    end
  elseif (Input.IsKeyPushed(Input.RIGHT)) then
    if (1 > x) then
      CurSel = CurSel + 1
      Good.SetPos(param.cur, 160 * (CurSel % 2), 5 + 120 * math.floor((CurSel / 2)))
    end
  end

  if (Input.IsKeyPushed(Input.LBUTTON)) then
    local x,y = Input.GetMousePos()
    for i = 1,8 do
      local px,py = (160 - 110)/2 + 160 * ((i - 1) % 2), 5 + 120 * math.floor(((i - 1) / 2))
      if (x >= px and x < px + 110 and y >= py and y < py + 110) then
        if (CurSel + 1 ~= i) then
          CurSel = i - 1
          Good.SetPos(param.cur, 160 * (CurSel % 2), 5 + 120 * math.floor((CurSel / 2)))
        else
          PlayGame(CurSel)
        end
        return
      end
    end
  end

  if (Input.IsKeyPressed(Input.RETURN + Input.BTN_A)) then
    PlayGame(CurSel)
  end
end

