
Good Game Editor/Player ���g���C���s�边
Copyright (c) 2007-2016 Waync Cheng


Good Game Editor/Player is provided as freeware for educational use, including
commercial use.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


Copyright
---------

  Audiere
    Copyright (c) Chad Austin 2001-2003
    Chad Austin is reachable at http://aegisknight.org

  Lua-5.1.4
    Copyright (C) 1994-2008 Lua.org, PUC-Rio.
    http://www.lua.org/license.html

  WTL 8.1
    Copyright (C) Microsoft Corporation. All rights reserved.
    Common Public License 1.0 (http://opensource.org/licenses/cpl1.0.php)

  yardparser-1.5
    Public domain, by Christopher Diggins
    http://www.cdiggins.com

  zlib-1.2.8
    Copyright (C) 1995-2004 Jean-loup Gailly and Mark Adler
