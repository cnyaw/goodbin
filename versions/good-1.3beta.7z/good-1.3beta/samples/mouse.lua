
local font = Resource.GetTextureId('font')

local mx, my
local ks

local text = nil

function UpdateMessage()
  local x, y = Input.GetMousePos()
  local k = Input.IsKeyDown(Input.LBUTTON + Input.RBUTTON)

  if (x == mx and y == my and k == ks) then
    return
  end

  mx = x
  my = y
  ks = k

  local str = "Mouse: (" .. mx .. ", " .. my .. ")"

  if (Input.IsKeyDown(Input.LBUTTON)) then
    str = str .. " LButton"
  end

  if (Input.IsKeyDown(Input.RBUTTON)) then
    str = str .. " RButton"
  end

  if (nil ~= text) then
    Good.KillObj(text)
  end

  text = GenStringObj(32, 120, str, font, 16, 32)
end

Level = {}

Level.OnCreate = function(param)
  mx, my = Input.GetMousePos()
  ks = Input.IsKeyDown(Input.LBUTTON + Input.RBUTTON)
  UpdateMessage()
end

Level.OnStep = UpdateMessage
