
function PtInRect(x, y, left, top, right, bottom)
  if (left <= x and right > x and top <= y and bottom > y) then
    return true
  else
    return false
  end
end

function GenStringObj(x, y, str, texture, charw, charh)
  local dummy = Good.GenDummy(-1)
  Good.SetPos(dummy, x, y)

  for i = 1, string.len(str) do
    local o = Good.GenObj(dummy, texture)
    Good.SetPos(o, (i - 1) * charw, 0);
    local ch = string.byte(str, i) - 32
    local charx = charw * math.floor(ch % 15)
    local chary = charh * math.floor(ch / 15)
    Good.SetDim(o, charx, chary, charw, charh)
  end

  return dummy
end
