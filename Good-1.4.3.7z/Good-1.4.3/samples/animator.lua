
Anim1 = {}

Anim1.OnStep = function(param)
  if (nil == param.x) then
    local loop1 = ArAddLoop(nil)
    ArAddMoveBy(loop1, 'Rot', 0, 1)
    local loop2 = ArAddLoop(nil)
    ArAddMoveTo(loop2, 'Scale', 0.75, 0, 0).ease = ArEaseIn
    ArAddMoveTo(loop2, 'Scale', 0.75, 1, 1).ease = ArEaseOutElastic
    param.x = ArAddAnimator({loop1, loop2})
  else
    ArStepAnimator(param, param.x)
  end
end

Anim2 = {}

Anim2.OnCreate = function(param)
  local o = param._id
  local x,y = Good.GetPos(o)
  local lp = ArAddLoop(nil)
  local ar1 = ArAddMoveTo(lp, 'Pos', 2, 550, y)
  if (20 == o) then
    ar1.ease = ArEaseIn
  elseif (21 == o) then
    ar1.ease = ArEaseOut
  elseif (22 == o) then
    ar1.ease = ArEaseInOut
  elseif (23 == o) then
    ar1.ease = ArEaseOutIn
  end
  ArAddDelay(lp, 1)
  ArAddMoveTo(lp, 'Pos', 0, 96, y)
  local ar2 = ArAddMoveTo(lp, 'Pos', 2, 550, y)
  if (20 == o) then
    ar2.ease = ArEaseInBack
  elseif (21 == o) then
    ar2.ease = ArEaseOutBack
  elseif (22 == o) then
    ar2.ease = ArEaseInOutBack
  elseif (23 == o) then
    ar2.ease = ArEaseOutInBack
  end
  ArAddDelay(lp, 1)
  ArAddMoveTo(lp, 'Pos', 0, 96, y)
  local ar3 = ArAddMoveTo(lp, 'Pos', 2, 550, y)
  if (20 == o) then
    ar3.ease = ArEaseInBounce
  elseif (21 == o) then
    ar3.ease = ArEaseOutBounce
  elseif (22 == o) then
    ar3.ease = ArEaseInOutBounce
  elseif (23 == o) then
    ar3.ease = ArEaseOutInBounce
  end
  ArAddDelay(lp, 1)
  ArAddMoveTo(lp, 'Pos', 0, 96, y)
  local ar4 = ArAddMoveTo(lp, 'Pos', 2, 550, y)
  if (20 == o) then
    ar4.ease = ArEaseInElastic
  elseif (21 == o) then
    ar4.ease = ArEaseOutElastic
  elseif (22 == o) then
    ar4.ease = ArEaseInOutElastic
  elseif (23 == o) then
    ar4.ease = ArEaseOutInElastic
  end
  ArAddDelay(lp, 1)
  ArAddMoveTo(lp, 'Pos', 0, 96, y)
  param.k = ArAddAnimator({lp})
end

Anim2.OnStep = function(param)
  ArStepAnimator(param, param.k)
end

ToggleColorObj = function(param)
  local o = 26
  if (0xffff0000 == Good.GetBgColor(o)) then
    Good.SetBgColor(o, 0xff00ffff)
  else
    Good.SetBgColor(o, 0xffff0000)
  end
end

Anim3 = {}

Anim3.OnCreate = function(param)
  Good.SetAnchor(param._id, 0.5, 0.5)
  local loopn = ArAddLoop(nil)
  local loop2 = ArAddLoop(loopn, 2)
  ArAddMoveTo(loop2, 'Pos', 1, 450, 350)
  ArAddMoveTo(loop2, 'Pos', 2, 50, 200)
  ArAddMoveTo(loop2, 'Pos', 0.5, 450, 40)
  ArAddMoveTo(loopn, 'Pos', 1, 10, 310)
  ArAddMoveBy(loopn, 'Pos', 1, 40, 20)
  ArAddCall(loopn, 'ToggleColorObj', 0)

  local loopn2 = ArAddLoop(nil)
  ArAddMoveBy(loopn2, 'Rot', 1, 150)

  local loopn3 = ArAddLoop(nil)
  ArAddMoveBy(loopn3, 'Scale', 2, 1.5, 0)
  ArAddMoveBy(loopn3, 'Scale', 2, 0, 1.5)
  ArAddDelay(loopn3, 5)
  ArAddMoveBy(loopn3, 'Scale', 2, 0, -1.5)
  ArAddMoveBy(loopn3, 'Scale', 2, -1.5, 0)
  ArAddDelay(loopn3, 5)

  local loopn4 = ArAddLoop(nil, 5)
  ArAddMoveTo(loopn4, 'BgColor', 2, 0xffff0000)
  ArAddMoveTo(loopn4, 'BgColor', 2, 0xffffffff)
  
  param.k = ArAddAnimator({loopn, loopn2, loopn3, loopn4})
  param.x = true
end

Anim3.OnStep = function(param)
  ArStepAnimator(param, param.k)
end
