-- Time: continue time, in ticks. 0 means apply effect immediately.
-- Hits: hits count, apply effect times. Ignore if 0==Time.
-- Effect: EffectDataId

BuffData = {
  [1] = {Time = 0, Hits = 0, Effect = 1},
  [2] = {Time = 0, Hits = 0, Effect = 2},
  [3] = {Time = 100, Hits = 3, Effect = 3},
  [4] = {Time = 0, Hits = 0, Effect = 3},
  [5] = {Time = 0, Hits = 0, Effect = 4},
  [6] = {Time = 0, Hits = 0, Effect = 5}
}
